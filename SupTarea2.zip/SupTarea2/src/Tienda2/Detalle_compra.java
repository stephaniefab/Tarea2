
package Tienda2;

/**
 *
 * @author fabiola
 */
public class Detalle_compra {
   
    int cantidad;
    Articulo articulo;
    
    public Detalle_compra(int cantidad, Articulo articulo) {
        this.cantidad = cantidad;
        this.articulo = articulo;
    }

   
}
    
    
    
    
      
    


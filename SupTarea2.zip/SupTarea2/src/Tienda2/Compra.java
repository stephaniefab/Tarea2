
package Tienda2;

/**
 *
 * @author fabiola
 */
public class Compra{
  Direccion direccion;
  Pago pago;
  Detalle_compra detalle_compra;

    public Compra(Direccion direccion, Pago pago, Detalle_compra detalle_compra) {
        this.direccion = direccion;
        this.pago = pago;
        this.detalle_compra = detalle_compra;
    }
  
  
}


package Tienda2;

/**
 *
 * @author fabiola
 */
public class Pago {
    int pago;
    String id_pago;

    public Pago(int pago, String id_pago) {
        this.pago = pago;
        this.id_pago = id_pago;
    }
    
    
}

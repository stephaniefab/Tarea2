
package Tienda2;

/**
 *
 * @author fabiola
 */
public class Direccion {
    int municipio;
    int departamento;
    String direccion;

    public Direccion(int municipio, int departamento, String direccion) {
        this.municipio = municipio;
        this.departamento = departamento;
        this.direccion = direccion;
    }    
}

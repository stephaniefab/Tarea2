
package Tienda2;

/**
 *
 * @author eacdv
 */
public class L_Articulo{
    int articulo;
    String nom_articulo;
    float precio;
    
}

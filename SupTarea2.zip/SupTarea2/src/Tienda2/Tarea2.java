
package Tienda2;

import javax.swing.JFrame;

/**
 *
 * @author eacdv
 */
public class Tarea2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        TiendaPrincipal miframe= new TiendaPrincipal();
        miframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        miframe.setSize(600,350);
        miframe.setVisible(true);
    }
    
}

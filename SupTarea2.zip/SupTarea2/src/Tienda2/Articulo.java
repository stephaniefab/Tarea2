
package Tienda2;

/**
 *
 * @author fabiola
 */
public class Articulo {
    int articulo;
    String nomb_articulo;

    public Articulo(int articulo, String nomb_articulo) {
        this.articulo = articulo;
        this.nomb_articulo = nomb_articulo;
    }
    
    
}
